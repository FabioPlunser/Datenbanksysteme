CREATE INDEX index_name
ON title_akas (ordering ASC);