EXPLAIN SELECT * 
From title_akas 
WHERE titleId = 'tt6996876' AND region = 'DE';