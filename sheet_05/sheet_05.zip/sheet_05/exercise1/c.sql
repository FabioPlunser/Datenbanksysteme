INSERT INTO employee(firstname, lastname, main_location) VALUES
		('Erika', 'Mustermann', 'UIBK'),
		('Moritz', 'Mustermann', 'Uni Salzburg'),
		('Peter', 'Mustermann', 'New York'),
		('Max', 'Mustermann', 'Uni Graz');
INSERT INTO project(name, main_location) VALUES
		('project2', 'UIBK'),
		('project Mayhem', 'New York'),
		('project5', 'TU Wien');
