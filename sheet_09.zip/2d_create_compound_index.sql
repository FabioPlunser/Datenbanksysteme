CREATE INDEX compound_index
ON title_akas (region ASC, titleId ASC);